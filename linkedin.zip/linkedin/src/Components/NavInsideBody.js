import { useState } from "react";
const style1 = {
    fontWeight: '700',
    paddingBottom: '15px',
    color: 'orange',
    borderBottom: '2px solid orange'
}
function NavInsideBody () {
    const [flag, setFlag] = useState(1);
    return(<div style={{
        paddingTop: '20px',
        marginTop: '10px',
        width: '100%',
        backgroundColor: 'white',
        display: 'flex',
        justifyContent: 'space-evenly'
    }}>
        {console.log(flag)}
        {flag === 1 ? <span style={style1}>Overview</span> : <span onClick={() => {
            setFlag(1);
        }}>Overview</span> }
    
        {flag === 2 ? <span style={style1}>About</span> : <span onClick={() => {
            setFlag(2);
        }}>About</span> }

        {flag === 3 ? <span style={style1}>Products</span> : <span onClick={() => {
            setFlag(3);
        }}>Products</span> }

        {flag === 4 ? <span style={style1}>Posts</span> : <span onClick={() => {
            setFlag(4);
        }}>Posts</span> }

        {flag === 5 ? <span style={style1}>Jobs</span> : <span onClick={() => {
            setFlag(5);
        }}>Jobs</span> }

        {flag === 6 ? <span style={style1}>People</span> : <span onClick={() => {
            setFlag(6);
        }}>People</span> }

        {flag === 7 ? <span style={style1}>Videos</span> : <span onClick={() => {
            setFlag(7);
        }}>Videos</span> }
    </div>)
}

export default NavInsideBody;