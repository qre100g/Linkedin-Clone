function About () {
    return(<div style={{
        backgroundColor: 'white',
        marginTop: '10px',
        padding: '20px'
    }}>
        <h2>About</h2>
        <span>
            Figma is the first professional-grade online tool created specifically for interface design. Born on the Web, Figma helps the entire product team create, test,
            and ship better designs, faster.
        </span>
    </div>)
}


export default About;