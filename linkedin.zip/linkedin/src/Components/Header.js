import "./header.css";
import  logo from '../Images/logo.png';

function Header () {
    return (
        <div className="flexBox">
            <img src= {logo} alt="Linkedin- Logo" height={50} width={50} />  
            <div className="search">
                <span className="material-icons">
                    search
                </span>
                <input placeholder="Search"/>
            </div>
            <span className='material-icons'>notifications</span>
            <span className="material-icons">sms</span>
            <span className="material-icons" >apps</span>
            <div style={{backgroundColor:'yellow', padding : '10px 10px', border: '1px solid black', color:'black'}}>
                Upgrade to premium
            </div>
        </div>
    );
}
export default Header;