import { useContext } from "react/cjs/react.production.min";
import { uContext } from "../App";
import image from '../Images/figma.jpeg';
import icon from '../Images/figmaIcon.jpeg';

const style1 = {
    display : 'flex',
    alignItems : 'center',
    justifyContent : 'space-between',
    marginTop: 20,
    width : 300
}


export function Hello() {

    return (
        <div style={{
            marginTop: '20px',
            backgroundColor: 'white',
            position: 'relative'
        }}>
            <img src= {image} width = '100%' />
            <img src= {icon} height = '120px' style={{
                position: 'absolute',
                left: '30px',
                top: '160px'
            }}/>

            <div style={{
                margin: '80px 0px 0px 30px',
                paddingBottom: '30px'
            }}>
                <h1>Figma</h1>
                <h3>A design platform for teams who build products together</h3>
                <span style={{
                    fontSize: '12px'
                }}>Design . Sanfrancisco,CA . 101,282 followers</span>
                <h5 style={{
                    color: 'blue'
                }}>See all 358 employees on LinkedIn</h5>

                <div style={{
                    display: 'flex'
                }}>
                    <div style={{
                        marginRight: '10px',
                        backgroundColor: 'blue',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-evenly',
                        width: '100px',
                        padding: '5px'

                    }}>
                        <span className="material-icons">
                            visibility
                        </span>
                        <span>Follow</span>
                    </div>
                    <div style={{
                        marginRight: '10px',
                        display: 'flex',
                        alignItems: 'center',
                        border: '1px solid black',
                        justifyContent: 'space-evenly',
                        width: '150px',
                        padding : '5px'
                    }}>
                        <span class="material-icons">
                        ios_share
                        </span>
                        <span>Visit website</span>
                    </div>
                    <span class="material-icons" style={{
                        border: '1px solid black',
                        padding: '5px'
                    }}>
                        more_horiz
                    </span>
                </div>
            </div>


            
            
        </div>
    )
}

function Company (props) {
    return (
        <div style={style1}>
            <img src = {props.logo} alt='hi' height={30}/>
            <div style={{lineHeight: 0.1, margin:'0px 20px', marginTop: '-15px', flex : 1}}>
                <h3>
                    {props.title}
                </h3>
                <span style={{fontSize: '10px'}}>{props.category} . {props.count} followers</span>
                

            </div>
            <span className="material-icons"> visibility</span>
        </div>
    )
}
export default Company;