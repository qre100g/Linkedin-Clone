function IconNameComp (props) {
    const iconAlignment = {
        display : 'flex',
        alignItems : 'center',

    }
    return (
        <div style={iconAlignment}>
            <span className="material-icons" style={{marginRight:10}}>
                {props.icon}
            </span>
            <span>
                {props.name}
            </span>
        </div>
    )
}

export default IconNameComp;