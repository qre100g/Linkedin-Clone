
import IconNameComp from "./IconNameComp";

function Nav () {
    const icon = ['home','people_alt','work_outline','person_outline'];
    const name = ['Home','My network','Job offers','My profile'];
    
    return (
        <div style={{
            backgroundColor: 'white',
            'display' :'flex', justifyContent : 'space-around', padding: '10px 0px'}}>
            <IconNameComp icon={icon[0]} name = {name[0]} />
            <IconNameComp icon = {icon[1]} name = {name[1]} />
            <IconNameComp icon = {icon[2]} name = {name[2]} />
            <IconNameComp icon = {icon[3]} name = {name[3]} />
        </div>
    )
}
export default Nav;