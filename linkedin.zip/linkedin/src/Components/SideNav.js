import Company from "./Company";
import dribble from '../Images/dribble.jpeg'
import sketch from '../Images/sketch.png';
import behance from '../Images/behance.png';
import medium from '../Images/medium.png';
import slack from '../Images/slack.jpeg';
import adobe from '../Images/adobe.jpeg';
const data = [['Dribbble', 'Design', '162K'],
                ['Sketch','Design', '33K'],
                ['Behance', 'Internet', '67K'],
                ['Overlap Studio', 'Information Technology & Services', '105'],
                ['Medium', 'Online Media', '101K'],
                ['Adobe', 'Computer Software', '2,68M'],
                ['Slack', 'Computer Software', '582K']
]
function SideNav () {
    return (
        <div style={{
            marginTop: '20px',
            height: '350px',
            backgroundColor: 'white',
            padding: '20px'
        }}>
            <h4>Pages people also viewed</h4>
            <Company logo = {dribble} title = {data[0][0]} category = {data[0][1]} count = {data[0][2]}/>
            <Company logo = {sketch} title = {data[1][0]} category = {data[1][1]} count = {data[1][2]}/>
            <Company logo = {behance} title = {data[2][0]} category = {data[2][1]} count = {data[2][2]} />
            <Company logo = {medium} title = {data[4][0]} category = {data[4][1]} count = {data[4][2]} />
            <Company logo = {adobe} title = {data[5][0]} category = {data[5][1]} count = {data[5][2]} />
            <Company logo = {slack} title = {data[6][0]} category = {data[6][1]} count = {data[6][2]} />

        </div>
    ) 
}
export default SideNav;