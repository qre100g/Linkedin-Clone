import React from "react";
import Header from "./Components/Header";
import Nav from "./Components/Nav";
import SideNav from "./Components/SideNav";
import { useState } from "react";
import { Hello } from "./Components/Company";
import NavInsideBody from "./Components/NavInsideBody";
import About from "./Components/Sections";

export const uContext = React.createContext();

function App() {
  const [name , setName] = useState('mukesh');
  const age = 23;
  return (<div style={{
    backgroundColor: 'lightblue'
  }}>
    <uContext.Provider value={name}>
        <Header> </Header>
        <Nav> </Nav>
        <div style={{
          display: 'flex',
          justifyContent: 'space-evenly'
        }}>
          <div style={{
            width: '60%'
          }}>
            <Hello/>
            <NavInsideBody/>
            <About/>
          </div>
          
          <SideNav/>
        </div>
    </uContext.Provider>
  </div>);
}

export default App;
